public class BulbAdapter implements SmartDevice {

    private final LegacyBulb device;
    private final int studentKey;

    public static final int DEFAULT_K = 4;

    public BulbAdapter(LegacyBulb device) {
        this(device, DEFAULT_K);
    }

    public BulbAdapter(LegacyBulb device, int k) {
        if (device == null) {
            throw new IllegalArgumentException("Device cannot be null.");
        }
        this.device = device;
        this.studentKey = k;
    }

    @Override
    public void turnon() {
        this.device.setBrightness(255);
    }

    public void turnOn() {
        this.turnon();
    }

    @Override
    public void turnoff() {
        this.device.setBrightness(0);
    }

    public void turnOff() {
        this.turnoff();
    }

    @Override
    public boolean ison() {
        if (!this.device.hasPower()) {
            return false;
        }
        return this.device.readBrightness() > 0;
    }

    public boolean isOn() {
        return this.ison();
    }

    @Override
    public int getPowerPercent() {
        if (!this.device.hasPower()) {
            return 0;
        }

        int currentBrightness = this.device.readBrightness();

        if (currentBrightness == 0) {
            return 0;
        }

        int basePercent = (currentBrightness * 100) / 255;
        int adjustedPercent = basePercent + this.studentKey;

        return Math.min(100, adjustedPercent);
    }
}

