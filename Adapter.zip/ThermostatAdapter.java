public class ThermostatAdapter implements SmartDevice {

    private final LegacyThermostat legacyThermostat;

    public ThermostatAdapter(LegacyThermostat legacyThermostat) {
        if (legacyThermostat == null) {
            throw new IllegalArgumentException("Thermostat reference cannot be null.");
        }
        this.legacyThermostat = legacyThermostat;
    }

    @Override
    public void turnon() {
        String dialPosition = this.legacyThermostat.checkDial();

        if ("IDLE".equalsIgnoreCase(dialPosition)) {
            this.legacyThermostat.rotateDial("LOW");
        }
    }

    public void turnOn() {
        this.turnon();
    }

    @Override
    public void turnoff() {
        this.legacyThermostat.rotateDial("IDLE");
    }

    public void turnOff() {
        this.turnoff();
    }

    @Override
    public boolean ison() {
        String state = this.legacyThermostat.checkDial();

        if (state == null) {
            return false;
        }

        switch (state.toUpperCase().trim()) {
            case "LOW":
            case "MEDIUM":
            case "MAX":
                return true;
            case "IDLE":
            default:
                return false;
        }
    }

    public boolean isOn() {
        return this.ison();
    }

    @Override
    public int getPowerPercent() {
        String state = this.legacyThermostat.checkDial();

        if (state == null) {
            return -1;
        }

        switch (state.toUpperCase().trim()) {
            case "IDLE":
                return 0;
            case "LOW":
                return 33;
            case "MEDIUM":
                return 66;
            case "MAX":
                return 100;
            default:
                return -1;
        }
    }
}
