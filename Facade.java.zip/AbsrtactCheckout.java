package com.ecommerce;
import java.math.BigDecimal;
public abstract class AbsrtactCheckout {
    protected boolean validateOrder(String productId, String customerId,
                                    String address, BigDecimal amount) {

        return productId != null && !productId.trim().isEmpty()
                && customerId != null && !customerId.trim().isEmpty()
                && address != null && !address.trim().isEmpty()
                && amount != null
                && amount.compareTo(BigDecimal.ZERO) > 0;}
    public abstract boolean placeOrder(
            String productId,
            String customerId,
            String address,
            BigDecimal amount
    );
}
