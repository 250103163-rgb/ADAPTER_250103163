package LAB2;

public class CityRacer {
    interface Movement {
        double getSpeed();
        String getName();
    }
    static class Walking implements Movement {
        double speed = 5;
        String name = "Walking";
        public double getSpeed() {
            return speed;
        }
        public String getName() {
            return name;
        }
    }
    static class Skateboarding implements Movement {
        double speed = 15;
        String name = "Skateboarding";
        public double getSpeed() {
            return speed;
        }
        public String getName() {
            return name;
        }
    }
    static class Jetpack implements Movement {
        double speed = 60;
        String name = "Jetpack";
        public double getSpeed() {
            return speed;
        }
        public String getName() {
            return name;
        }
    }
    static class Player {
        Movement movement;
        String nick;
        public Player(String nick, Movement movement) {
            this.nick = nick;
            this.movement = movement;
        }
        public void setMovement(Movement movement) {
            this.movement = movement;
        }
        public void move() {
            System.out.println(nick + " is " + movement.getName() + " at " + movement.getSpeed() + " km/h");
        }
    }
    static public class main {
        public static void main(String[] args) {
            Player p = new Player("Malika", new Walking());
            p.move();
            p.move();
            p.setMovement(new Skateboarding());
            p.move();
            p.setMovement(new Jetpack());
            p.move();
            p.move();
        }
    }
}
