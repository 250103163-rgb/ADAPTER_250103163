package LAB2;
public class PizzaBuilder {
    interface Pizza {
        double getPrice();
        String getDescription();
    }
    class PlainPizza implements Pizza {
        public double getPrice() {
            return 5.0;
        }
        public String getDescription() {
            return "Plain Dough & Sauce";
        }
    }
    abstract class ToppingDecorator implements Pizza {
        protected final Pizza pizza;
        ToppingDecorator(Pizza pizza) {
            this.pizza = pizza;
        }
        public String getDescription() {
            return pizza.getDescription() + ", " + name();
        }
        public double getPrice() {
            return pizza.getPrice() + cost();
        }
        protected abstract String name();
        protected abstract double cost();
    }
    class Cheese extends ToppingDecorator {
        Cheese(Pizza p) {
            super(p);
        }
        protected String name() {
            return "Cheese";
        }
        protected double cost() {
            return 2.0;
        }
    }
    class Olives extends ToppingDecorator {
        Olives(Pizza p) {
            super(p);
        }
        protected String name() {
            return "Olives";
        }
        protected double cost() {
            return 1.0;
        }
    }

    class Pineapple extends ToppingDecorator {
        Pineapple(Pizza p) {
            super(p);
        }
        protected String name() {
            return "Pineapple";
        }
        protected double cost() {
            return 1.5;
        }
    }
    public class main {
        public static void main(String[] args){
            Pizza pizza = new Pineapple(new Olives(new Cheese(new PlainPizza())));
            System.out.println("Description: " + pizza.getDescription());
            System.out.printf("Total cost: $%.2f%n", pizza.getPrice());
        }
    }
}