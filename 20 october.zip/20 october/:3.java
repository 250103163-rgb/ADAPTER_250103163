package LAB2;

public class RetroGame {
    interface DigitalGame {
        void playDigital();
    }
    static class ModernConsole {
        public void run(DigitalGame game) {
            System.out.println("Console is starting the game...");
            game.playDigital();
        }
    }
    static class RetroCartridge {
        String title = "Super Mario";

        public void insertCartridge() {
            System.out.println("Cartridge " + title + " is loaded. Let's play!");
        }
    }
    static class CartridgeAdapter implements DigitalGame {
        RetroCartridge cartridge;
        public CartridgeAdapter(RetroCartridge cartridge) {
            this.cartridge = cartridge;
        }
        public void playDigital() {
            cartridge.insertCartridge();
        }
    }
    public class main {
        public static void main(String[] args) {
            ModernConsole console = new ModernConsole();
            RetroCartridge cartridge = new RetroCartridge();
            CartridgeAdapter adapter = new CartridgeAdapter(cartridge);
            console.run(adapter);
        }
    }
}
